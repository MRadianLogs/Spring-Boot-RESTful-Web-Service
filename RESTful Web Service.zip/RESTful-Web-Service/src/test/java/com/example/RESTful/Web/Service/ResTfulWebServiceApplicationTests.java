package com.example.RESTful.Web.Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResTfulWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
