package com.example.RESTful.Web.Service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResTfulWebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResTfulWebServiceApplication.class, args);
	}

}
